README V1.3.2

Vielen Dank, das du MineWeb Gedownloadet Hasst. Ich wünsche dir viel spaß mit der Webseite, und hoffe, das dir das Webseiten-Template gefällt.
Thank you for downloading MineWeb. I wish you a lot of fun with the website, and hope that you like the website template.


- Bei Fragen Schreibt mich bitte per Discord/PM.
- If you have any questions, please write me by Discord/PM.


- Discord [Frage-Server]: Kommt Bald.
- Discord [Question Server]: Coming Soon.


- PM [Spigot] https://www.spigotmc.org/resources/mineweb-webseite-zum-download-ger-de.79217/


- Persönliche Gespräche per Discord/TS müssen mit mir abgesprochen sein [ Bitte schreibt mich persönlich per PM An! ]
- Personal conversations via Discord/TS must be agreed with me [ Please write me personally via PM An! ] 

 