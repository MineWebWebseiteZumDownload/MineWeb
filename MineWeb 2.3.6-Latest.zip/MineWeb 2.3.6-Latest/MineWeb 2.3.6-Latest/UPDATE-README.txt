UPDATE-README 


# - Neu in MineWeb 2.3.6:
# - New in MineWeb 2.3.6:

- Bug fixes [ Wobei die Über-Uns Seite nicht geladen hat b.z.w nicht erkannt wurde ]
- Neue Funktionen [ Mehr Funktionen auf der gesamten Webseite ]


# Vorschläge

- Wenn ihr Vorschläge habt, was ich/wir noch an der Webseite Hinzufügen könnten, schreibt mich bitte per PM an!
- If you have any suggestions as to what I/we could add to the website, please write to me via PM!